﻿#if INTERACTIVE 
//Math.Net Numerics
#r @"..\packages\MathNet.Numerics.2.1.2\lib\Net40\MathNet.Numerics.dll"
#r @"..\packages\MathNet.Numerics.FSharp.2.1.2\lib\Net40\MathNet.Numerics.FSharp.dll"
//PowerPack
#r @"..\packages\FSPowerPack.Community.2.1.1.1\Lib\Net40\FSharp.PowerPack.dll"
#r @"..\packages\FSPowerPack.Community.2.1.1.1\Lib\Net40\FSharp.PowerPack.Linq.dll"
#r @"..\packages\FSPowerPack.Community.2.1.1.1\Lib\Net40\FSharp.PowerPack.Metadata.dll"
#r @"..\packages\FSPowerPack.Community.2.1.1.1\Lib\Net40\FSharp.PowerPack.Parallel.Seq.dll"
//FSharpChart
#r @"..\packages\MSDN.FSharpChart.dll.0.60\lib\MSDN.FSharpChart.dll"
#load "FSharpChart.fsx"
//HtmlAgility
#r @"..\packages\HtmlAgilityPack.1.4.3\lib\HtmlAgilityPack.dll"
#r @"System.Xml"
#r @"System.Xml.Linq"
#endif

open System
open System.Collections.Generic
open System.Linq
open System.Text
open System.IO
open System.Drawing
open System.Windows.Forms
open System.Windows.Forms.DataVisualization.Charting
open System.Xml
open System.Xml.Linq

open MathNet.Numerics
open MathNet.Numerics.FSharp
open MathNet.Numerics.LinearAlgebra.Double
open MathNet.Numerics.LinearAlgebra.IO
open MathNet.Numerics.Distributions
open MSDN.FSharp.Charting  //FSharpChart
open HtmlAgilityPack       //HtmlAgility
open Microsoft.FSharp.Math //PowerPack